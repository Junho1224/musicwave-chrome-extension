"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const vm = require("node:vm");
const { readFileSync } = require("node:fs");
const { join } = require("node:path");

async function loadContent({ text = "", bodyText = text, settings = {}, respond } = {}) {
  let now = 100000;
  let messageListener;
  let settingsListener;
  let toastCount = 0;
  const messages = [];
  const media = { currentTime: 10, paused: false, ended: false, seeking: false };
  class Element {
    constructor() { this.style = {}; this.innerText = text; this.textContent = text; }
    getBoundingClientRect() { return { width: 300, height: 200 }; }
    querySelector() { return null; }
    closest() { return null; }
    append() {}
    setAttribute() {}
    addEventListener() {}
    remove() {}
    attachShadow() { toastCount++; return new Element(); }
  }
  const modal = new Element();
  const currentSettings = { alertsEnabled: false, ntfyEnabled: true,
    soundEnabled: false, titleFlashEnabled: false, ...settings };
  const context = vm.createContext({
    Date: class extends Date { static now() { return now; } },
    HTMLElement: Element,
    MutationObserver: class { observe() {} },
    getComputedStyle: () => ({ display: "block", visibility: "visible", opacity: "1" }),
    document: {
      body: { innerText: bodyText }, documentElement: new Element(),
      querySelector(selector) { return selector.startsWith("#alertButton")
        ? (text ? modal : null) : selector.includes("audio") ? media : null; },
      querySelectorAll() { return []; },
      getElementById() { return null; }, createElement() { return new Element(); },
      addEventListener() {}
    },
    chrome: {
      runtime: {
        id: "test-extension",
        async sendMessage(message) {
          if (message.signal) {
            messages.push(message);
            return respond ? respond(message, messages.length) : { remote: { delivered: true } };
          }
          return { registered: true };
        },
        onMessage: { addListener(listener) { messageListener = listener; } }
      },
      storage: {
        sync: { async get(defaults) { return { ...defaults, ...currentSettings }; } },
        onChanged: { addListener(listener) { settingsListener = listener; } }
      }
    }
  });
  const window = { setTimeout() { return 1; }, clearTimeout() {},
    setInterval() { return 2; }, clearInterval() {}, addEventListener() {} };
  window.top = window;
  context.window = window;
  for (const file of ["detector-core.js", "playback-monitor-core.js", "content.js"]) {
    vm.runInContext(readFileSync(join(__dirname, "..", file), "utf8"), context);
  }
  const flush = async () => { for (let index = 0; index < 12; index++) await Promise.resolve(); };
  await flush();
  return {
    messages, media,
    advance(ms) { now += ms; },
    async scan() {
      let status;
      messageListener({ type: "MUSIC_WAVE_SCAN_NOW" }, {}, (value) => { status = value; });
      await flush();
      return status;
    },
    updateSettings(values) {
      Object.assign(currentSettings, values);
      settingsListener(Object.fromEntries(Object.entries(values).map(([key, newValue]) =>
        [key, { newValue }])), "sync");
    },
    get toastCount() { return toastCount; }
  };
}

test("detects the verified modal even when body text misses its warning", async () => {
  const { messages } = await loadContent({
    text: "지금 듣고계신 음악을 계속 들으시겠습니까?", bodyText: ""
  });
  assert.equal(messages.length, 1);
  assert.equal(messages[0].signal.kind, "continue");
});

test("retries a failed desktop message without repeating the page alert", async () => {
  const content = await loadContent({
    text: "계속 들으시겠습니까?", settings: { alertsEnabled: true, ntfyEnabled: false },
    respond: (_message, attempt) => {
      if (attempt === 1) throw new Error("receiver-unavailable");
      return { notified: true, desktop: { delivered: true } };
    }
  });
  content.advance(16000);
  await content.scan();
  await content.scan();
  assert.equal(content.messages.length, 2);
  assert.equal(content.toastCount, 1);
});

test("retries only the phone after a successful PC delivery", async () => {
  const content = await loadContent({
    text: "기계적인 스트리밍 패턴이 감지되어 인증을 진행합니다.",
    settings: { alertsEnabled: true },
    respond: (_message, attempt) => ({ notified: true, remote: { delivered: attempt > 1 } })
  });
  assert.equal(content.messages[0].type, "MUSIC_WAVE_ALERT");
  content.advance(16000);
  await content.scan();
  assert.equal(content.messages[1].type, "MUSIC_WAVE_ALERT_RETRY_REMOTE");
  assert.equal(content.toastCount, 1);
});

test("delivers an existing warning when notifications are enabled", async () => {
  const content = await loadContent({ text: "계속 들으시겠습니까?",
    settings: { alertsEnabled: false, ntfyEnabled: false } });
  assert.equal(content.messages.length, 0);
  content.updateSettings({ ntfyEnabled: true });
  await content.scan();
  assert.equal(content.messages.length, 1);
});

test("a silent playback stop sends one alert and rearms after resume", async () => {
  const content = await loadContent();
  content.media.paused = true;
  content.advance(16000);
  const status = await content.scan();
  assert.equal(status.activeSignals[0], "playbackStopped");
  assert.equal(content.messages[0].signal.kind, "playbackStopped");
  await content.scan();
  assert.equal(content.messages.length, 1);
  content.media.paused = false;
  content.media.currentTime = 11;
  await content.scan();
  content.media.paused = true;
  content.advance(16000);
  await content.scan();
  assert.equal(content.messages.length, 2);
});

test("a visible confirmation sends its own alert instead of a duplicate stop alert", async () => {
  const content = await loadContent({ text: "계속 들으시겠습니까?" });
  content.media.paused = true;
  content.advance(16000);
  await content.scan();
  assert.deepEqual(content.messages.map((message) => message.signal.kind), ["continue"]);
});
